package CodeGeneration;

public class LabelGenerator {
    private static int count = 0;

    public static String getLabel(String type) {
        count++;
        return "label_" + type + "_"+ count;
    }
}
